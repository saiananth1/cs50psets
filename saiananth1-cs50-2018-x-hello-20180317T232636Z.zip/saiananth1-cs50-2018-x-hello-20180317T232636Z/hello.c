//Prompts Hello World upon executing this program
#include <stdio.h>
int main(void)
{
    printf("Hello, world!\n");
}
